const SchoolAbout = () => {
	return (
		<div className="SchoolAbout">
			<div className="content">
				<h3>About Us</h3>
				<p>
					Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam
					dignissimos culpa reprehenderit voluptatum necessitatibus nam atque
					est commodi, vero, eveniet natus facilis voluptates sit excepturi
					mollitia architecto perferendis minus? Aliquid.
				</p>
			</div>
			<img src="/action.jpg" alt="About" />
		</div>
	);
};

export default SchoolAbout;
